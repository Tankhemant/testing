﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(mvc_Assignment_hemanttank.Startup))]
namespace mvc_Assignment_hemanttank
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
