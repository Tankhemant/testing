﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace mvc_Assignment_hemanttank.BAL
{
    public class Helaper
    {
        public NpgsqlConnection conn = new NpgsqlConnection(ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString);
    }
}