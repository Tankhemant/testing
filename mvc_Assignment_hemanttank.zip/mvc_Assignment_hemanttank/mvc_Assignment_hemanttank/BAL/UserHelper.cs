﻿using mvc_Assignment_hemanttank.Models;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace mvc_Assignment_hemanttank.BAL
{
    public class UserHelper : Helaper
    {
        public void Register(User user)
        {
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into t_user(name,email,password)values(@name,@email,@password);";
            cmd.Parameters.AddWithValue("@name", user.name);
            cmd.Parameters.AddWithValue("@email", user.email);
            cmd.Parameters.AddWithValue("@password", user.password);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();


        }

        public bool Login(LoginModel user)
        {
            bool loginsucces = false;
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from t_user where email=@email AND password=@password;";
            cmd.Parameters.AddWithValue("@email", user.email);
            cmd.Parameters.AddWithValue("@password", user.password);
            conn.Open();
            NpgsqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                HttpContext.Current.Session["userid"] = Convert.ToInt32(dr["id"]);
                return loginsucces = true;
            }
            return loginsucces;
        }

        public bool EmailLogin(string email)
        {
            bool EmailisWrite = false;
            NpgsqlCommand cmd = new NpgsqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from t_user where email=@email;";
            cmd.Parameters.AddWithValue("@email",email);
            conn.Open();
            NpgsqlDataReader dr = cmd.ExecuteReader();
            if(dr.Read())
            {
                EmailisWrite = true;
            }
            conn.Close();
            return EmailisWrite;


        }
    }
}