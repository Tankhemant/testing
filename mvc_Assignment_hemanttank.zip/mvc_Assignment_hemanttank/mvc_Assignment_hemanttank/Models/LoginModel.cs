﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace mvc_Assignment_hemanttank.Models
{
    public class LoginModel
    {
        [Display(Name = "Email")]
        [Required(ErrorMessage = "Please Enter Email")]
        public string email { get; set; }
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Please Enter A Password")]
        public string password { get; set; }
    }
}