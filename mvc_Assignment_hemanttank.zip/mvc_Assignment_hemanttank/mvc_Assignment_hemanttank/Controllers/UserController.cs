﻿using mvc_Assignment_hemanttank.BAL;
using mvc_Assignment_hemanttank.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc_Assignment_hemanttank.Controllers
{
    public class UserController : Controller
    {
        UserHelper u = new UserHelper();
        // GET: User
        public ActionResult Index()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Index(User user)
        {
            u.Register(user);
            return RedirectToAction("Login","User");
        }

        public ActionResult Login()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Login(LoginModel lm)
        {
            if (u.Login(lm))
            {
                TempData["alertmessage"] = "Login";
                return RedirectToAction("Index", "User");
            }
            TempData["alertmessage"] = "Password or Email is Wrong";
            return RedirectToAction("Login","User");
        }
        public ActionResult EmailLogin(string email)
        {
            string message = "succesfully Login";
            if (u.EmailLogin(email))
            {
                return Json(new { isEmailExists = true, message = message }, JsonRequestBehavior.AllowGet);
                TempData["alertmessage"] = "Login";
            }
            return Json(new { isemailexist = false, }, JsonRequestBehavior.AllowGet);
        }
    }
}